#pragma once
#ifndef WIFI_CONFIG_H
#define WIFI_CONFIG_H

#define YOUR_WIFI_SSID "YOUR_WIFI_SSID"
#define YOUR_WIFI_PASSWD "YOUR_WIFI_PASSWD"

#endif //WIFI_CONFIG_H